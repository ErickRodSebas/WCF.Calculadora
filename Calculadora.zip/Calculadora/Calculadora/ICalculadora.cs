﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Calculadora
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface ICalculadora
    {
        [OperationContract]
        double Sumar(double a, double b);

        [OperationContract]
        double Restar(double a, double b);

        [OperationContract]
        double Multiplicar(double a, double b);

        [OperationContract]
        double Dividir(double a, double b);

        [OperationContract]
        double Potencia(double a, double b);

        [OperationContract]
        double Modulo(double a, double b);
    }
}
